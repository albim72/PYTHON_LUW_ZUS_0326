# Metaclass auto-inference (JSON / CSV / XML)

## Idea
Metaklasa `WriterMeta` tworzy rejestr klas-writerów (pluginów) na podstawie atrybutu `format_name`.
Następnie metoda `WriterMeta.create_for(data)` automatycznie wybiera writer na podstawie struktury danych.

## Inferencja (meta.infer_format)
1) XML: dict z jednym root-tag (np. {'person': {...}}) => xml
2) CSV: list[dict] o spójnych kluczach i skalarnych wartościach => csv
3) JSON: wszystko inne => json

## Uruchomienie
python main.py

Wygeneruje:
- out.csv
- out.xml
- out.json
