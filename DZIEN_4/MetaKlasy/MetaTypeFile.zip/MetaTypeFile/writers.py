from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import json
import csv
import io
import xml.etree.ElementTree as ET

from meta import BaseWriter


@dataclass
class JsonWriter(BaseWriter):
    format_name: str = "json"
    indent: int = 2
    ensure_ascii: bool = False

    def dumps(self) -> str:
        return json.dumps(self.data, indent=self.indent, ensure_ascii=self.ensure_ascii)


def _to_xml(parent: ET.Element, obj: Any) -> None:
    """Konwersja dict/list/scalar -> XML.
    - dict: klucze => tagi
    - list: elementy => powtarzalne <item>
    - scalar: tekst
    """
    if obj is None:
        return
    if isinstance(obj, dict):
        for k, v in obj.items():
            child = ET.SubElement(parent, str(k))
            _to_xml(child, v)
    elif isinstance(obj, list):
        for item in obj:
            child = ET.SubElement(parent, "item")
            _to_xml(child, item)
    else:
        parent.text = str(obj)


@dataclass
class XmlWriter(BaseWriter):
    format_name: str = "xml"
    xml_declaration: bool = True
    encoding: str = "utf-8"

    def dumps(self) -> str:
        if not isinstance(self.data, dict) or len(self.data) != 1:
            raise ValueError("XML inference expects dict with a single root key, e.g. {'root': {...}}")

        (root_tag, root_obj), = self.data.items()
        root = ET.Element(str(root_tag))
        _to_xml(root, root_obj)

        xml_bytes = ET.tostring(root, encoding=self.encoding, xml_declaration=self.xml_declaration)
        return xml_bytes.decode(self.encoding)


@dataclass
class CsvWriter(BaseWriter):
    format_name: str = "csv"
    delimiter: str = ","

    def dumps(self) -> str:
        if not isinstance(self.data, list) or not self.data or not all(isinstance(x, dict) for x in self.data):
            raise ValueError("CSV inference expects a non-empty list of dict rows")

        fieldnames = list(self.data[0].keys())
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=fieldnames, delimiter=self.delimiter)
        writer.writeheader()
        for row in self.data:
            writer.writerow(row)
        return buf.getvalue()
