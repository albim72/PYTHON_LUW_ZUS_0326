from __future__ import annotations

from meta import BaseWriter
import writers  # noqa: F401  (import rejestruje klasy writerów)


def demo() -> None:
    # 1) CSV: lista słowników o tych samych kluczach i skalarnych wartościach
    data_csv = [
        {"date": "2026-03-01", "athlete": "Marcin", "activity": "run", "distance_km": 10.0, "time_min": 45},
        {"date": "2026-03-02", "athlete": "Ewa", "activity": "run", "distance_km": 5.0, "time_min": 28},
    ]

    # 2) XML: dict z jednym root-tag
    data_xml = {
        "person": {
            "name": "Marcin",
            "age": 53,
            "skills": ["Python", "AI", "ETL"],
            "meta": {"role": "trainer", "level": "pro"}
        }
    }

    # 3) JSON: fallback
    data_json = {
        "project": "ANIMA",
        "notes": ["resonance", "pipeline", "field"],
        "metrics": {"itrapoints": 421, "goal": 500}
    }

    mydata = {
        "Warszawa":{
            "id":1,
            "wnioski":220,
            "projekty":12,
            "budżet":23_243_000
        },
        "Lublin": {
            "id": 2,
            "wnioski": 167,
            "projekty": 9,
            "budżet": 11_209_000
        },
        "Kraków": {
            "id": 3,
            "wnioski": 201,
            "projekty": 11,
            "budżet": 17_900_000
        }
    }

    for i, (data, out) in enumerate(
        [(data_csv, "out.csv"), (data_xml, "out.xml"), (data_json, "out.json"),(mydata, "out_m.csv")],
        start=1
    ):
        writer = BaseWriter.create_for(data)
        print(f"[{i}] inferred={writer.format_name} -> saving {out}")
        writer.save(out)

    print("\nDone. Files generated: out.csv, out.xml, out.json")


if __name__ == "__main__":
    demo()
