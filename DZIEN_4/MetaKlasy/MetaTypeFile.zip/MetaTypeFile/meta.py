from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, Type


def _is_scalar(x: Any) -> bool:
    return x is None or isinstance(x, (str, int, float, bool))


_TAG_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_.-]*$")


def _looks_like_xml_root_dict(d: dict) -> bool:
    """Heurystyka XML:
    - dokładnie 1 klucz na najwyższym poziomie (root tag)
    - klucz wygląda jak nazwa taga XML
    """
    if not isinstance(d, dict) or len(d) != 1:
        return False
    (root,) = d.keys()
    return isinstance(root, str) and bool(_TAG_RE.match(root))


def infer_format(data: Any) -> str:
    """Automatyczna inferencja formatu bez pola 'type'.

    Reguły (kolejność ma znaczenie):
    1) XML: dict z jednym root-tag (np. {'person': {...}}) => 'xml'
    2) CSV: lista słowników o tych samych kluczach i skalarnych wartościach => 'csv'
    3) JSON: wszystko inne => 'json'
    """
    # 1) XML
    if isinstance(data, dict) and _looks_like_xml_root_dict(data):
        return "xml"

    # 2) CSV: list[dict] o spójnych kluczach i skalarnych wartościach
    if isinstance(data, list) and data and all(isinstance(x, dict) for x in data):
        keys = None
        for row in data:
            row_keys = tuple(row.keys())
            if keys is None:
                keys = row_keys
            elif row_keys != keys:
                return "json"
            if not all(_is_scalar(v) for v in row.values()):
                return "json"
        return "csv"

    # 3) JSON (fallback)
    return "json"


class WriterMeta(type):
    """Metaklasa:
    - rejestruje klasy-writer'y po atrybucie format_name
    - udostępnia create_for(data), które wybiera writer na podstawie infer_format()
    """
    registry: Dict[str, Type["BaseWriter"]] = {}

    def __new__(mcls, name, bases, attrs):
        cls = super().__new__(mcls, name, bases, attrs)
        fmt = attrs.get("format_name")
        if isinstance(fmt, str) and fmt:
            mcls.registry[fmt] = cls
        return cls

    def create_for(mcls, data: Any, **kwargs) -> "BaseWriter":
        fmt = infer_format(data)
        writer_cls = mcls.registry.get(fmt)
        if writer_cls is None:
            raise ValueError(f"No writer registered for format={fmt!r}")
        return writer_cls(data=data, **kwargs)


@dataclass
class BaseWriter(metaclass=WriterMeta):
    """Bazowy writer. Konkrety implementują dumps() i ewentualnie nadpisują save()."""
    data: Any
    format_name: str = ""

    def dumps(self) -> str:
        raise NotImplementedError

    def save(self, path: str) -> None:
        text = self.dumps()
        with open(path, "w", encoding="utf-8", newline="") as f:
            f.write(text)
